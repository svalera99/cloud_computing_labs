import base64
import functions_framework
import os
import json

import firebase_admin
from firebase_admin import firestore

os.environ['GOOGLE_CLOUD_PROJECT'] = "botattempt-1567093478511"
app = firebase_admin.initialize_app()

@functions_framework.cloud_event
def write_to_db(cloud_event):
    data = json.loads(base64.b64decode(
        cloud_event.data["message"]["data"]
    ))
    msg_id = data.get("id", None)
    if msg_id is None:
      return "Msg coudn't be stored due to lacking id"
    msg_body = data.get("other_data", "")

    db = firestore.client()
    collection = db.collection('my-collection')
    inx = 0
    while True:
      doc_name = f"{msg_id}_{inx}"
      if collection.document(doc_name).get().exists:
        inx += 1
      else:
        break

    doc_ref = collection.document(f"{msg_id}_{inx}")
    doc_ref.set({
        'id': str(msg_id),
        'other_data': msg_body
    })

    print("Document added.")
