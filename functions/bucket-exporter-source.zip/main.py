import functions_framework
import time
from google.cloud import firestore_admin_v1
import os

@functions_framework.http
def export_firestore(request):
    project_id = os.getenv('GCP_PROJECT')
    bucket = os.getenv('BUCKET_NAME')
    client = firestore_admin_v1.FirestoreAdminClient()
    database_name = f'projects/{project_id}/databases/(default)'

    output_uri_prefix = f'gs://{bucket}/firestore-backups/manual-trigger-{time.time()}'
    response = client.export_documents(
        request={
            "name": database_name,
            "output_uri_prefix": output_uri_prefix,
            "collection_ids": []
        }
    )
    return 'Backup initiated.'